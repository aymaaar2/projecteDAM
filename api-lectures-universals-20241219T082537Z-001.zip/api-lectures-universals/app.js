const express = require('express');
const app = express();
const fs = require('fs');
const port = 3000;

app.use(express.json());

function llegirDades() {
  const dadesJSON = fs.readFileSync('./data/lectures-universals.json', 'utf8');
  return JSON.parse(dadesJSON);
}

function escriureDades(dades) {
  const dadesJSON = JSON.stringify(dades, null, 2);
  fs.writeFileSync('./data/lectures-universals.json', dadesJSON);
}

app.post('/lectures-universals', (req, res) => {
  const dades = llegirDades();
  const nouLlibre = {
    id: dades.length + 1,
    autor: req.body.autor,
    genere: req.body.genere,
    any: req.body.any
  };
  dades.push(nouLlibre);
  escriureDades(dades);
  res.status(201).json(nouLlibre);
});

app.get('/lectures-universals', (req, res) => {
  const dades = llegirDades();
  res.json(dades);
});

app.get('/lectures-universals/:id', (req, res) => {
  const dades = llegirDades();
  const id = parseInt(req.params.id);
  let llibre = null;

  for (let i = 0; i < dades.length; i++) {
    if (dades[i].id === id) {
      llibre = dades[i];
      break;
    }
  }

  if (llibre) {
    res.json(llibre);
  } else {
    res.status(404).send('Llibre no trobat');
  }
});

app.put('/lectures-universals/:id', (req, res) => {
  const dades = llegirDades();
  const id = parseInt(req.params.id);
  let llibreActualitzat = null;

  for (let i = 0; i < dades.length; i++) {
    if (dades[i].id === id) {
      dades[i].marca = req.body.marca || dades[i].marca;
      dades[i].model = req.body.model || dades[i].model;
      dades[i].any = req.body.any || dades[i].any;
      motoActualitzada = dades[i];
      break;
    }
  }

  if (motoActualitzada) {
    escriureDades(dades);
    res.json(motoActualitzada);
  } else {
    res.status(404).send('Motocicleta no trobada');
  }
});
